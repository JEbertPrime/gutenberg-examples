/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdateminimal_react_webpack_babel_setup"]("main",{

/***/ "./src/containers/SeaLevelRise.jsx":
/*!*****************************************!*\
  !*** ./src/containers/SeaLevelRise.jsx ***!
  \*****************************************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: /Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/src/containers/SeaLevelRise.jsx: Unexpected token (38:115)\\n\\n\\u001b[0m \\u001b[90m 36 |\\u001b[39m                 }}\\u001b[0m\\n\\u001b[0m \\u001b[90m 37 |\\u001b[39m             \\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 38 |\\u001b[39m             \\u001b[33m<\\u001b[39m\\u001b[33mRow\\u001b[39m style\\u001b[33m=\\u001b[39m{{ padding\\u001b[33m:\\u001b[39m \\u001b[32m'5em 0em 0em 0em'\\u001b[39m\\u001b[33m,\\u001b[39m height\\u001b[33m:\\u001b[39m \\u001b[32m'calc(100vh - 99px)'\\u001b[39m\\u001b[33m,\\u001b[39m minHeight\\u001b[33m:\\u001b[39m\\u001b[32m'max-content'\\u001b[39m\\u001b[33m,\\u001b[39m zIndex\\u001b[33m=\\u001b[39m\\u001b[32m'10'\\u001b[39m }}\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m                                                                                                                    \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 39 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mCol\\u001b[39m md\\u001b[33m=\\u001b[39m\\u001b[32m'3'\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 40 |\\u001b[39m                 \\u001b[0m\\n\\u001b[0m \\u001b[90m 41 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mCol\\u001b[39m md\\u001b[33m=\\u001b[39m\\u001b[32m'4'\\u001b[39m style\\u001b[33m=\\u001b[39m{{  color\\u001b[33m:\\u001b[39m \\u001b[32m'#fef9ef'\\u001b[39m }}\\u001b[33m>\\u001b[39m\\u001b[0m\\n    at Object._raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:816:17)\\n    at Object.raiseWithData (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:809:17)\\n    at Object.raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:770:17)\\n    at Object.unexpected (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:9905:16)\\n    at Object.checkExpressionErrors (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:9994:12)\\n    at Object.parseMaybeAssign (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10657:12)\\n    at Object.parseExpressionBase (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10576:23)\\n    at /Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10570:39\\n    at Object.allowInAnd (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:12345:12)\\n    at Object.parseExpression (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10570:17)\");\n\n//# sourceURL=webpack://minimal-react-webpack-babel-setup/./src/containers/SeaLevelRise.jsx?");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("3551e109bfa778a6c952")
/******/ })();
/******/ 
/******/ }
);