/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdateminimal_react_webpack_babel_setup"]("main",{

/***/ "./src/containers/Heat.jsx":
/*!*********************************!*\
  !*** ./src/containers/Heat.jsx ***!
  \*********************************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: /Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/src/containers/Heat.jsx: Unexpected token, expected \\\",\\\" (48:44)\\n\\n\\u001b[0m \\u001b[90m 46 |\\u001b[39m     \\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 47 |\\u001b[39m         \\u001b[33m<\\u001b[39m\\u001b[33mRow\\u001b[39m  style\\u001b[33m=\\u001b[39m{{position\\u001b[33m:\\u001b[39m\\u001b[32m'absolute'\\u001b[39m\\u001b[33m,\\u001b[39m zIndex\\u001b[33m:\\u001b[39m\\u001b[32m'1'\\u001b[39m}}\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 48 |\\u001b[39m             \\u001b[33m<\\u001b[39m\\u001b[33mCol\\u001b[39m style\\u001b[33m=\\u001b[39m{{paddingLeft\\u001b[33m:\\u001b[39m\\u001b[32m'10px'\\u001b[39m color\\u001b[33m:\\u001b[39m\\u001b[32m'white'\\u001b[39m\\u001b[33m,\\u001b[39m paddingTop\\u001b[33m:\\u001b[39m\\u001b[32m'50px'\\u001b[39m}}\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m                                             \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 49 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mOrangeHeader\\u001b[39m className\\u001b[33m=\\u001b[39m\\u001b[32m'center'\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[35m2.\\u001b[39m \\u001b[33mGeorgia\\u001b[39m is getting hotter\\u001b[33m.\\u001b[39m\\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mOrangeHeader\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 50 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mp\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[33mGeorgia\\u001b[39m experienced record\\u001b[33m-\\u001b[39msetting heat \\u001b[36min\\u001b[39m \\u001b[35m2016\\u001b[39m\\u001b[33m,\\u001b[39m \\u001b[35m2017\\u001b[39m\\u001b[33m,\\u001b[39m and \\u001b[35m2019.\\u001b[39m \\u001b[33mMore\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 51 |\\u001b[39m frequent and intense heat waves are projected\\u001b[33m.\\u001b[39m \\u001b[33mExtreme\\u001b[39m heat threatens\\u001b[0m\\n    at Object._raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:816:17)\\n    at Object.raiseWithData (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:809:17)\\n    at Object.raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:770:17)\\n    at Object.unexpected (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:9905:16)\\n    at Object.expect (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:9879:28)\\n    at Object.parseObjectLike (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:11694:14)\\n    at Object.parseExprAtom (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:11222:23)\\n    at Object.parseExprAtom (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5245:20)\\n    at Object.parseExprSubscripts (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10878:23)\\n    at Object.parseUpdate (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:10858:21)\");\n\n//# sourceURL=webpack://minimal-react-webpack-babel-setup/./src/containers/Heat.jsx?");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("8dcf3b0be0931af78ec2")
/******/ })();
/******/ 
/******/ }
);