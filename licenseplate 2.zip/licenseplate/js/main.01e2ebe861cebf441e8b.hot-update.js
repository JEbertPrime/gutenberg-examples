/*
 * ATTENTION: The "eval" devtool has been used (maybe by default in mode: "development").
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
self["webpackHotUpdateminimal_react_webpack_babel_setup"]("main",{

/***/ "./src/containers/SeaLevelRise.jsx":
/*!*****************************************!*\
  !*** ./src/containers/SeaLevelRise.jsx ***!
  \*****************************************/
/***/ (() => {

eval("throw new Error(\"Module build failed (from ./node_modules/babel-loader/lib/index.js):\\nSyntaxError: /Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/src/containers/SeaLevelRise.jsx: JSX value should be either an expression or a quoted JSX text. (67:160)\\n\\n\\u001b[0m \\u001b[90m 65 |\\u001b[39m                     \\u001b[0m\\n\\u001b[0m \\u001b[90m 66 |\\u001b[39m             \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mdiv\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m\\u001b[31m\\u001b[1m>\\u001b[22m\\u001b[39m\\u001b[90m 67 |\\u001b[39m                 \\u001b[33m<\\u001b[39m\\u001b[33mimg\\u001b[39m src\\u001b[33m=\\u001b[39m{\\u001b[32m`wp-content/themes/licenseplate/assets/images/layer_${level % 7}.png`\\u001b[39m} alt\\u001b[33m=\\u001b[39m{\\u001b[32m`Sea level rise of ${level} feet in Savannah, GA`\\u001b[39m} style\\u001b[33m=\\u001b[39m \\u001b[33m/\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m    |\\u001b[39m                                                                                                                                                                 \\u001b[31m\\u001b[1m^\\u001b[22m\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 68 |\\u001b[39m         \\u001b[33m<\\u001b[39m\\u001b[33m/\\u001b[39m\\u001b[33mContainer\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 69 |\\u001b[39m         \\u001b[33m<\\u001b[39m\\u001b[33mCollapse\\u001b[39m isOpen\\u001b[33m=\\u001b[39m{collapse}\\u001b[33m>\\u001b[39m\\u001b[0m\\n\\u001b[0m \\u001b[90m 70 |\\u001b[39m             \\u001b[33m<\\u001b[39m\\u001b[33mContainer\\u001b[39m\\u001b[33m>\\u001b[39m\\u001b[0m\\n    at Object._raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:816:17)\\n    at Object.raiseWithData (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:809:17)\\n    at Object.raise (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:770:17)\\n    at Object.jsxParseAttributeValue (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5075:20)\\n    at Object.jsxParseAttribute (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5114:46)\\n    at Object.jsxParseOpeningElementAfterName (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5134:28)\\n    at Object.jsxParseOpeningElementAt (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5127:17)\\n    at Object.jsxParseElementAt (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5159:33)\\n    at Object.jsxParseElementAt (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5175:32)\\n    at Object.jsxParseElementAt (/Users/nakfi/Documents/GitHub/gutenberg-examples/react-app/node_modules/@babel/parser/lib/index.js:5175:32)\");\n\n//# sourceURL=webpack://minimal-react-webpack-babel-setup/./src/containers/SeaLevelRise.jsx?");

/***/ })

},
/******/ function(__webpack_require__) { // webpackRuntimeModules
/******/ "use strict";
/******/ 
/******/ /* webpack/runtime/getFullHash */
/******/ (() => {
/******/ 	__webpack_require__.h = () => ("66559f1e3d736725538a")
/******/ })();
/******/ 
/******/ }
);