=== License Plate ===

== Description ==
The License Plate theme is a custom theme for https://www.georgiaclimateproject.org.

== Installation ==

1. In cPanel, add emorypph/ to wp-content
2. In your admin panel, go to Appearance -> Themes.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Customize in your admin panel.
